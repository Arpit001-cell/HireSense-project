package in.hiresense.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class AffindaAPI {

    private static final String API_KEY = "aff_f1f814bbb0bfea6cfe31ff1aed91e7fa5ff98a66";

    public static String analyzeResume(File resumeFile) throws IOException {
        String boundary = "----WebKitFormBoundary" + UUID.randomUUID();
        String LINE_FEED = "\r\n";

        URL url = new URL("https://api.affinda.com/v2/resumes");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
        connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        connection.setDoOutput(true);

        try (OutputStream output = connection.getOutputStream();
             PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8), true)) {

            writer.append("--" + boundary).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + resumeFile.getName() + "\"")
                    .append(LINE_FEED);
            writer.append("Content-Type: application/pdf").append(LINE_FEED);
            writer.append(LINE_FEED).flush();

            Files.copy(resumeFile.toPath(), output);
            output.flush();

            writer.append(LINE_FEED).flush();
            writer.append("--" + boundary + "--").append(LINE_FEED);
            writer.flush();
        }

        InputStream responseStream = connection.getResponseCode() == 200
                ? connection.getInputStream()
                : connection.getErrorStream();

        return new String(responseStream.readAllBytes(), StandardCharsets.UTF_8);
    }

    // Extract Skills
    public static List<String> extractSkills(String resultJson) {
        List<String> skills = new ArrayList<>();

        try {
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resultJson, JsonObject.class);

            JsonObject data = root.getAsJsonObject("data");
            JsonArray skillArray = data.getAsJsonArray("skills");

            if (skillArray != null) {
                for (JsonElement element : skillArray) {
                    JsonObject skillObj = element.getAsJsonObject();
                    String name = skillObj.get("name").getAsString();
                    skills.add(name.trim().toLowerCase());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return skills;
    }

    // Extract Summary
    public static String extractSummary(String resultJson) {
        try {
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resultJson, JsonObject.class);

            JsonObject data = root.getAsJsonObject("data");
            JsonArray sections = data.getAsJsonArray("sections");

            for (JsonElement element : sections) {
                JsonObject obj = element.getAsJsonObject();
                String sectionType = obj.get("sectionType").getAsString();

                if (sectionType.equalsIgnoreCase("Summary")) {
                    return obj.get("text").getAsString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // Extract Personal Details
    public static String extractPersonalDetails(String resultJson) {
        try {
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resultJson, JsonObject.class);

            JsonObject data = root.getAsJsonObject("data");
            JsonArray sections = data.getAsJsonArray("sections");

            for (JsonElement element : sections) {
                JsonObject obj = element.getAsJsonObject();
                String sectionType = obj.get("sectionType").getAsString();

                if (sectionType.equalsIgnoreCase("PersonalDetails")) {
                    return obj.get("text").getAsString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // Extract Education
    public static String extractEducation(String resultJson) {
        try {
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resultJson, JsonObject.class);

            JsonObject data = root.getAsJsonObject("data");
            JsonArray sections = data.getAsJsonArray("sections");

            for (JsonElement element : sections) {
                JsonObject obj = element.getAsJsonObject();
                String sectionType = obj.get("sectionType").getAsString();

                if (sectionType.equalsIgnoreCase("Education")) {
                    return obj.get("text").getAsString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // Extract Work Experience
    public static String extractWorkExperience(String resultJson) {
        String experience = null;
        String totalExp = null;

        try {
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resultJson, JsonObject.class);

            JsonObject data = root.getAsJsonObject("data");
            totalExp = data.get("totalYearsExperience").getAsString();

            JsonArray sections = data.getAsJsonArray("sections");

            for (JsonElement element : sections) {
                JsonObject obj = element.getAsJsonObject();
                String sectionType = obj.get("sectionType").getAsString();

                if (sectionType.equalsIgnoreCase("WorkExperience")) {
                    experience = obj.get("text").getAsString();
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "Total Experience : " + totalExp + "\n" + experience;
    }

    // Match Score
    public static int calculateMatchScore(String jobSkillsCsv, List<String> resumeSkills) {

        if (resumeSkills == null || resumeSkills.isEmpty()) {
            return 0;
        }

        String[] jobSkills = jobSkillsCsv.split(",");
        Set<String> required = new HashSet<>();

        for (String js : jobSkills) {
            required.add(js.trim().toLowerCase());
        }

        int matched = 0;
        for (String skill : resumeSkills) {
            if (required.contains(skill)) {
                matched++;
            }
        }

        return (int) ((matched * 100.0) / required.size());
    }
}
