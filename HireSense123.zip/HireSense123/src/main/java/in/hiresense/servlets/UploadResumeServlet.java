package in.hiresense.servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import in.hiresense.dao.ResumeAnalysisLogDAO;
import in.hiresense.models.ResumeAnalysisLogPojo;
import in.hiresense.utils.AffindaAPI;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@WebServlet("/UploadResumeServlet")
@MultipartConfig
public class UploadResumeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");

        Part filePart = request.getPart("resume");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        // ► Step 1: Upload directory
        String uploadDir = getServletContext().getRealPath("/resumes");
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File resumeFile = new File(dir, fileName);

        // ► Step 2: Delete previous resume
        try {
            List<ResumeAnalysisLogPojo> logs = ResumeAnalysisLogDAO.getLogsByUser(userId);

            if (!logs.isEmpty()) {
                Gson gson = new Gson();
                JsonObject obj = gson.fromJson(logs.get(0).getResultJson(), JsonObject.class);
                JsonObject data = obj.getAsJsonObject("data");

                if (data != null && data.has("resumePath")) {
                    String prevPath = data.get("resumePath").getAsString();
                    File oldFile = new File(prevPath);
                    if (oldFile.exists()) {
                        oldFile.delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ► Step 3: Save new resume file
        try (InputStream input = filePart.getInputStream();
             FileOutputStream out = new FileOutputStream(resumeFile)) {

            byte[] buffer = new byte[1024];
            int len;

            while ((len = input.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
        }

        // ► Step 4: Send to Affinda & store log
        try {
            String resultJson = AffindaAPI.analyzeResume(resumeFile);

            Gson gson = new Gson();
            JsonObject resultObj = gson.fromJson(resultJson, JsonObject.class);

            JsonObject dataObj = resultObj.getAsJsonObject("data");
            if (dataObj != null) {
                // Add local file path inside the data
                dataObj.addProperty("resumePath", resumeFile.getAbsolutePath());
            }

            // Save final JSON string
            ResumeAnalysisLogDAO.saveLog(userId, gson.toJson(resultObj));

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("userDashboard");
    }
}
