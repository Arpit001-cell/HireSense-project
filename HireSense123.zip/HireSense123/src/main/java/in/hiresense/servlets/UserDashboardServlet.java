package in.hiresense.servlets;

import java.io.IOException;
import java.util.*;

import com.google.gson.*;

import in.hiresense.dao.*;
import in.hiresense.models.*;
import in.hiresense.utils.AffindaAPI;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/userDashboard")
public class UserDashboardServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");

        try {
            List<ResumeAnalysisLogPojo> logs = ResumeAnalysisLogDAO.getLogsByUser(userId);
            boolean resumeUploaded = !logs.isEmpty();

            List<String> userSkills = null;

            if (resumeUploaded) {
                JsonObject obj = JsonParser.parseString(logs.get(0).getResultJson()).getAsJsonObject();
                userSkills = AffindaAPI.extractSkills(obj.toString());
            }

            // Load Jobs
            List<JobPojo> jobs =
                    JobDAO.getAllJobsForUserDashboard(
                            request.getParameter("search"),
                            request.getParameter("sort"),
                            request.getParameter("location"),
                            request.getParameter("experience"),
                            request.getParameter("packageLpa")
                    );

            // Calculate Match Score
            if (resumeUploaded && userSkills != null) {
                for (JobPojo job : jobs) {
                    int score = AffindaAPI.calculateMatchScore(job.getSkills(), userSkills);
                    job.setScore(score);
                }
            }

            // Applied Jobs
            List<ApplicationPojo> applied = ApplicationDAO.getApplicationsByUser(userId);
            Set<Integer> appliedIds = new HashSet<>();
            for (ApplicationPojo app : applied) {
                appliedIds.add(app.getJobId());
            }

            // Set Data to JSP
            request.setAttribute("jobs", jobs);
            request.setAttribute("appliedJobIds", appliedIds);
            request.setAttribute("resumeUploaded", resumeUploaded);

            request.getRequestDispatcher("userDashboard.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
