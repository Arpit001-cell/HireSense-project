package in.hiresense.servlets;

import java.io.IOException;
import java.util.List;

import in.hiresense.dao.ApplicationDAO;
import in.hiresense.dao.JobDAO;
import in.hiresense.dao.ResumeAnalysisLogDAO;
import in.hiresense.dao.UserDAO;
import in.hiresense.models.ApplicationPojo;
import in.hiresense.models.JobPojo;
import in.hiresense.models.ResumeAnalysisLogPojo;
import in.hiresense.models.UserPojo;
import in.hiresense.utils.MailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/ApplyJobServlet")
public class ApplyJobServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("userId") == null 
                || !"user".equals(session.getAttribute("userRole"))) {

            res.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        int jobId = Integer.parseInt(req.getParameter("jobId"));
        double score = Double.parseDouble(req.getParameter("score"));

        try {

            String resumePath = "N/A";

            // ✔ Get latest resume analysis log
            List<ResumeAnalysisLogPojo> logs = ResumeAnalysisLogDAO.getLogsByUser(userId);

            if (!logs.isEmpty()) {

                String resultJson = logs.get(0).getResultJson();

                // 🔥 Using GSON instead of org.json
                Gson gson = new Gson();
                JsonObject root = gson.fromJson(resultJson, JsonObject.class);

                JsonObject data = root.getAsJsonObject("data");

                if (data != null && data.has("resumePath")) {
                    resumePath = data.get("resumePath").getAsString();
                }
            }

            // ✔ Save Application
            ApplicationPojo app = new ApplicationPojo(
                    0, userId, jobId, resumePath, score, "applied", null
            );

            ApplicationDAO.apply(app);

            // ✔ Mail Notifications
            UserPojo user = UserDAO.getUserById(userId);
            JobPojo job = JobDAO.getJobById(jobId);

            MailUtil.sendApplicationConfirmation(
                    user.getName(), user.getEmail(), job.getTitle(), job.getCompany()
            );

            UserPojo employer = UserDAO.getUserById(job.getEmployerId());

            MailUtil.sendNewApplicationNotificationToEmployer(
                    employer.getName(), employer.getEmail(), user.getName(), job.getTitle()
            );

            res.sendRedirect("userDashboard?success=applied");

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("userDashboard?error=apply_failed");
        }
    }
}
